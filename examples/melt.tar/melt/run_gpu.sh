/home/nmr/scft/pscfpp/bin/pscf_pg1d -e -p param -c command -1 1 -2 128
#/home/nmr/scft/pscfpp/bin/
